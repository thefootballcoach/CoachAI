import DashboardLayout from '../layout/dashboard-layout';

export default DashboardLayout;
export { DashboardLayout };